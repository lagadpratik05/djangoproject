from django.shortcuts import render
from .models import Destination

def destinations_list(request):
    destinations = Destination.objects.filter(status="available")
    return render(
        request,
        "destinations/destinations.html",
        {"destinations": destinations}
    )

from django.shortcuts import get_object_or_404

from django.shortcuts import render, get_object_or_404
from .models import Destination

def destination_detail(request, pk):
    destination = get_object_or_404(Destination, id=pk)
    return render(request, "destinations/destination_detail.html", {
        "destination": destination
    })
