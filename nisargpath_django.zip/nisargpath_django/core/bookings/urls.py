from django.urls import path
from .views import my_bookings, book_destination, cancel_booking

urlpatterns = [
    path('my-bookings/', my_bookings, name='my_bookings'),
    path('book/<int:destination_id>/', book_destination, name='book_destination'),
    path('cancel/<int:booking_id>/', cancel_booking, name='cancel_booking'),
]
    