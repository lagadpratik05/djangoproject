from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from destinations.models import Destination
from .models import Booking


@login_required
def my_bookings(request):
    bookings = Booking.objects.filter(user=request.user).order_by('-id')
    return render(request, 'bookings/my_bookings.html', {
        'bookings': bookings
    })


@login_required
def book_destination(request, destination_id):
    destination = get_object_or_404(Destination, id=destination_id)

    if request.method == "POST":
        start_date = request.POST.get("start_date")
        end_date = request.POST.get("end_date")
        persons = int(request.POST.get("persons"))
        mobile_number = request.POST.get("mobile_number")
        payment_screenshot = request.FILES.get("payment_screenshot")

        amount = destination.price * persons

        Booking.objects.create(
            user=request.user,
            destination=destination,
            start_date=start_date,
            end_date=end_date,
            persons=persons,
            mobile_number=mobile_number,
            amount=amount,
            payment_screenshot=payment_screenshot,
            status="pending"
        )

        messages.success(
            request,
            "Booking placed successfully! Awaiting confirmation."
        )
        return redirect("my_bookings")

    return render(
        request,
        "bookings/book_destination.html",
        {"destination": destination}
    )


@login_required
def cancel_booking(request, booking_id):
    booking = get_object_or_404(
        Booking,
        id=booking_id,
        user=request.user
    )

    if booking.status != "cancelled":
        booking.status = "cancelled"
        booking.save()
        messages.success(request, "Booking cancelled successfully.")

    return redirect("my_bookings")
